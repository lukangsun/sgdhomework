# -*- coding: utf-8 -*-
"""
Created on Mon Sep  20 19:29:31 2021

@author: Lukang Sun
"""

import numpy as np
import matplotlib.pyplot as plt
from numpy import random
import math
from random import sample

#define list of a b and calculate some key parameter

a = [2,4,6,3,2,9,6,7,11,45]  
ab = [2,4,6,3,2,9,6,7,11,45,1,2,3,4,5,6,7,8,9,11]                       
a_sum =  2381                                     
b = [1,2,3,4,5,6,7,8,9,11] 
b_sum = 56  
atb = 796                                                
L_max = 2025
L_ave = 238.1
mu = 238.1
x_min = -796/2381 
sigma = 3993.739347850591
tau_best = 10
tau = 10
                                       
 #define each function  and its gradient

class func:
    def __init__(self, a,b):
        self.a = a
        self.b = b
        
    def value(self,x):
        return  0.5*(self.a*x+self.b)**2

    def grad(self, x):
        return self.a*self.a*x+self.a*self.b


funct = []
for i in range(10):
    funct.append(func(ab[i],ab[i+10]))              

def fun_sum(x):
    sum = 0
    for j in range(10):
        sum +=funct[j].value(x)

    return 0.1*sum    
#nice tau sampling
def nicesam(tau):
    list1 = [0,1,2,3,4,5,6,7,8,9]                              
    return sample(list1,tau)


#hyper parameter
#iter = 10000
epsilon = 10**(-4)
stepsize = 20025**(-1)

init = 4
x = 0
num_r = 100
dis = []

#iteration

def expect(xx,yy,zz,dd,kk,jj):
    tau = xx 
    iter = yy
    num_round = zz
    initial = dd
    min = kk
    stepsizes = jj
    dis = 0

    for rd in range(num_round):
        x = initial
        traj = []
        traj.append(x)
        for i in range(iter):
            index = nicesam(tau)
            gradi = 0
            for k in index:
                gradi +=1/tau*funct[k].grad(x)
            x = x - stepsizes*gradi   
            traj.append(x)
        dis = dis + (traj[iter]-min)**2
    return dis/num_round

dis_final = []

for w in [1,3,5,7,9,10]:
    dis_tmp = []
    for i in [500,600,700,800,900,1000,1100,1200,1300,1400,1500]:
        dis_tmp.append(expect(w,i,num_r,init,x_min,stepsize))
    dis_final.append(dis_tmp)
print(dis_final)



#plot

X = [500,600,700,800,900,1000,1100,1200,1300,1400,1500]
Y = [1,3,5,7,9,10]
dis_fin = dis_final
for j in range(6):
    for p in range(11):
        dis_fin[j][p] = dis_fin[j][p]/(Y[j]*X[p])


i = 0
plt.ylim(10**-9,10**-7)
for ww in [1,3,5,7,9]:

    plt.plot(X,dis_final[i],linewidth = 0.6,label='tau = %d'%(ww))
    i += 1
plt.plot(X,dis_final[5],linewidth = 0.6,marker= '*',markersize = 3,label='tau = %d'%(10))

plt.xlabel('iteration')
plt.ylabel('Error ')
plt.legend()
plt.show()