# -*- coding: utf-8 -*-
"""
Created on Mon Sep  6 19:29:31 2021

@author: Lukang Sun
"""


import numpy as np
import matplotlib.pyplot as plt

def f(x,y):
    
    return 0.01*x**2+y**2

def gradient(x,y):
    
    return [0.02*x,2*y]

#parameter

iter = 100
initial = [5,5]
stepsize = 0.5
trajx = []
trajy = []

#gradient descent iteration

x = initial
trajx.append(x[0])
trajy.append(x[1])

for i in range(100):
    
    x[0] = x[0] - stepsize*gradient(x[0],x[1])[0]
    x[1] = x[1] - stepsize*gradient(x[0],x[1])[1]
    trajx.append(x[0])
    trajy.append(x[1])
    
#plot

x=np.linspace(0,6,1000)
y=np.linspace(0,6,1000)
X,Y = np.meshgrid(x,y)
z=f(X,Y)
plt.contour(x,y,z)
plt.plot(trajx,trajy,color='r')
plt.scatter(trajx,trajy,color='b')

